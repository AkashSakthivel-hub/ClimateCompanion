const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../data/agriculture_data.json');

// Helper to construct a simulated "AI" explanation
function generateExplanation(region, month, crop, risk) {
    const aiReasoningPatterns = [
        `Analyzing ${region}'s historical climate data for ${month}... High probability of ${risk}. Recommending ${crop} due to its resilience profile.`,
        `Based on regional agro-climatic zones and seasonal forecasts for ${month}, ${crop} shows the strongest yield potential. Factoring in systemic risk: ${risk}.`,
        `Cross-referencing soil moisture indices with the ${month} dataset. ${risk} detected. ${crop} is the optimal choice for mitigative adaptation.`,
        `Simulated crop growth models for ${region} in ${month} point to ${crop}. Weather anomaly detection flags: ${risk}. Advice generated for risk aversion.`,
        `Agent recommendation synthesized: The expected ${risk} during ${month} severely impacts traditional cash crops. Switching to ${crop} maximizes drought/flood tolerance.`
    ];
    // Pick a pseudo-random explanation based on region length so it's deterministic but varied
    const patternIndex = (region.length + month.length) % aiReasoningPatterns.length;
    return aiReasoningPatterns[patternIndex];
}

function getAdvice(region, month) {
    try {
        const fileContent = fs.readFileSync(dataPath, 'utf-8');
        const db = JSON.parse(fileContent);

        if (!db[region]) {
            return { error: `Region '${region}' not found in the knowledge base.` };
        }

        const monthData = db[region][month];
        if (!monthData) {
            return { error: `Data for month '${month}' in region '${region}' not available.` };
        }

        const explanation = generateExplanation(region, month, monthData.crop, monthData.risk);

        return {
            crop: monthData.crop,
            risk: monthData.risk,
            advice: monthData.advice,
            explanation: explanation
        };
    } catch (err) {
        console.error("Failed reading data file:", err);
        throw new Error("Data read failure");
    }
}

module.exports = {
    getAdvice
};
