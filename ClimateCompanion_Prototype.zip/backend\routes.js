const express = require('express');
const router = express.Router();
const advisor = require('./advisor');

// Endpoint: POST /api/advice
// Expected body: { region: "Tamil Nadu", month: "June" }
router.post('/advice', (req, res) => {
    const { region, month } = req.body;

    if (!region || !month) {
        return res.status(400).json({
            error: "Missing required fields: 'region' and/or 'month'."
        });
    }

    try {
        const adviceResult = advisor.getAdvice(region, month);

        if (adviceResult.error) {
            return res.status(404).json(adviceResult);
        }

        res.json(adviceResult);
    } catch (error) {
        console.error("Error generating advice:", error);
        res.status(500).json({ error: "Internal Server Error while generating AI advice." });
    }
});

module.exports = router;
